let customers = JSON.parse(localStorage.getItem('customers')) || 
   [ { username: 'Andrew', password: 'pass123', role: 'customer', moneyBalance: 10300.00, purchaseHistory: [] }]


let admins = JSON.parse(localStorage.getItem('admins')) || [
    { username: 'Admin', password: 'admin123', role: 'admin' }]

let sellers = JSON.parse(localStorage.getItem('sellers')) || 
  [ { 
        username: 'Mark', 
        password: 'pass456', 
        role: 'seller', 
        companyName: 'Seller Company', 
        itemsForSale: [
            { 
                id: 1, 
                name: 'Laptop', 
                price: 200.00, 
                quantity: 10,
                photo: './laptop.png' 
            },
            
            { 
                id: 2, 
                name: 'Computer', 
                price: 600.00, 
                quantity: 15,
                photo: './Computer.png' 
            },
            { 
                id: 3, 
                name: 'Smartphone', 
                price: 400.00, 
                quantity: 20,
                photo: './Screenshot 2024-03-18 194327.png' 
            },
            { 
                id: 4, 
                name: 'Gaming Pc', 
                price: 300.00, 
                quantity: 12,
                photo: './Computer.png' 
            },
            { 
                id: 5, 
                name: 'Headphones', 
                price: 50.00, 
                quantity: 30,
                photo: './Screenshot 2024-03-18 193740.png' 
            },{ 
                id: 6, 
                name: 'Smart Watch', 
                price: 150.00, 
                quantity: 25,
                photo: './laptop.png'  
            },
            { 
                id: 7, 
                name: 'Wireless Mouse', 
                price: 30.00, 
                quantity: 40,
                photo: './Screenshot 2024-03-18 193934.png' 
            },
            { 
                id: 8, 
                name: 'Portable Speaker', 
                price: 80.00, 
                quantity: 18,
                photo: './Screenshot 2024-03-18 193904.png' 
            },
            { 
                id: 9, 
                name: 'External Hard Drive', 
                price: 100.00, 
                quantity: 15,
                photo: './Screenshot 2024-03-18 193840.png' 
            },
            { 
                id: 10, 
                name: 'Bluetooth Earbuds', 
                price: 70.00, 
                quantity: 30,
                photo: './Screenshot 2024-03-18 193904.png' 
            }
        ],
        saleHistory: [] 
    }
  ]


//==Log in==
function openLoginForm() {
   document.querySelector('#loginForm').style.display= 'block';
}


function closeLoginForm() {
    document.querySelector('#loginForm').style.display = 'none';
}



function saveDataToLocalStorage() {
    localStorage.customers= JSON.stringify(customers);
    localStorage.admins= JSON.stringify(admins);
    localStorage.sellers= JSON.stringify(sellers);
}

let currentPurchaseItemId = null; 
let currentUser = null;
function login() {
    
    const username = document.querySelector('#username').value;
    const password = document.querySelector('#password').value;

    const validCustomer = customers.find(user => user.username === username && user.password === password);
    const validSeller = sellers.find(user => user.username === username && user.password === password);
    const validAdmin = admins.find(user => user.username === username && user.password === password);

    if (validCustomer) {
       
        console.log(validCustomer);
        currentUser = validCustomer;
        
        console.log(currentUser);
        alert('Customer login successful!');
        document.querySelector('#purchase-history').style.display = 'block';
        console.log(currentUser);
        closeLoginForm();
        updateLoginButton(); 
        displayProducts(); 
        generatePurchaseHistoryTable();
        displayHistory(); 
        clearLoginForm();
    } else if (validSeller) {
        
        currentUser = validSeller;
        console.log(currentUser);
        console.log(currentUser.saleHistory);
        alert('Seller login successful!');
        closeLoginForm();//

        updateLoginButton();
        displayProducts(); 
        displaySellerSaleHistory() /
        clearLoginForm();
    } else if (validAdmin) {
        
        currentUser = validAdmin;
        alert('Admin login successful!');
        closeLoginForm();
        updateLoginButton(); 
        displayProducts(); 
        if (currentUser && currentUser.role === 'admin') {
            document.querySelector('#adminText').style.display = 'block';
        }
        clearLoginForm();
    } else {
       
        alert('Invalid username or password. Please try again.');
    }
}

function clearLoginForm() {
    
    document.querySelector('#username').value = "";
    document.querySelector('#password').value = "";
}

function updateLoginButton() {
    
    const loginBTN = document.querySelector('#homeLoginButton');
    if (currentUser) { 
        loginBTN.textContent = 'Logout';
        loginBTN.removeEventListener('click', openLoginForm);
        loginBTN.addEventListener('click', logout);
    } else {
        loginBTN.textContent = 'Login';
        loginBTN.removeEventListener('click', logout);
        loginBTN.addEventListener('click', openLoginForm);
    }
}
//======log in==== 

//===Searching===
function searchProducts() {
    
    const searchValue = document.querySelector('#searchInput').value.toLowerCase();

   
    const productContainer = document.querySelector('.product-container');

   
    const productCards = document.querySelectorAll('.product-card');

    
    productCards.forEach(card => {
       
        const productName = card.querySelector('h3').textContent.toLowerCase();

       
        if (productName.includes(searchValue)) {
            
            card.style.display = 'block';
        } 
         else {
            
            card.style.display = 'none';
         
        } 
        
    });
}

function deleteItem(itemId) {
    localStorage.removeItem('sellers');
    const itemIndex = sellers[0].itemsForSale.findIndex(item => item.id === itemId);
    if (itemIndex !== -1) {
        sellers[0].itemsForSale.splice(itemIndex, 1);
        console.log('Item deleted successfully.');
        localStorage.sellers= JSON.stringify(sellers);
        displayProducts();
    } else {
        console.log('Item not found.');
    }
}
function logout() {
    
    saveDataToLocalStorage(currentUser);



    currentUser = null;
    document.querySelector('#adminText').style.display = 'none';
    document.querySelector('#uploadButton').style.display = 'none';
    displayProducts();
    document.querySelector('#purchase-history').style.display = 'none';
    document.querySelector('#sale-history').style.display = 'none';
    clearLoginForm();
    
    updateLoginButton();
}
function displayHistory() {
    const purchaseHistoryContainer = document.querySelector('.purchase-history-container');
    const saleHistoryContainer = document.querySelector('.sale-history-container');
    saleHistoryContainer.innerHTML = '';
    
        // Display purchase history for customers
        customers[0].purchaseHistory.forEach(purchase => {
            const purchaseCard = document.createElement('div');
            purchaseCard.classList.add('purchase-card');
            purchaseCard.innerHTML = `
                <p>Transaction ID: ${purchase.transactionId}</p>
                <p>Item Name: ${purchase.itemName}</p>
                <p>Quantity: ${purchase.quantity}</p>
                <p>Total Price: $${purchase.totalPrice.toFixed(2)}</p>
                <p>Delivery Address: ${purchase.buyerAddress}</p>
            `;
           
          
        });
        document.getElementById('purchase-history').style.display = 'block';
    
}

function displaySellerSaleHistory() {
    const saleHistoryContainer = document.querySelector('.sale-history-container');
    saleHistoryContainer.innerHTML = ''; 

   
    const seller = sellers.find(seller => seller.username === currentUser.username);

    if (seller) {
        seller.saleHistory.forEach(sale => {
            const saleCard = document.createElement('div');
            saleCard.classList.add('product-card');
            saleCard.innerHTML = `
                <img src="${sale.photo}" alt="${sale.name}">
                <h3>${sale.itemName}</h3>
                <p>Quantity: ${sale.quantity}</p>
                <p>Total Price: $${sale.totalPrice.toFixed(2)}</p>
                <p>Buyer Address: ${sale.buyerAddress}</p>
            `;
            saleHistoryContainer.appendChild(saleCard);
        });
        document.querySelector('#sale-history').style.display = 'block';
    }
}
function displayProducts() {

    const productContainer = document.querySelector('.product-container');

   
    productContainer.innerHTML = '';

  
    if (!currentUser) {
        sellers.forEach(seller => {
            seller.itemsForSale.forEach(item => {
                const productCard = document.createElement('div');
                productCard.classList.add('product-card');
                productCard.innerHTML = `
                    <img src="${item.photo}" alt="${item.name}">
                    <h3>${item.name}</h3>
                    <p>Quantity: ${item.quantity}</p>
                    <p>Price: $${item.price.toFixed(2)}</p>
                `;
                productContainer.appendChild(productCard);
            });
        });
    } else if (currentUser.role === 'seller') {
        
        currentUser.itemsForSale.forEach(item => {
            const productCard = document.createElement('div');
            productCard.classList.add('product-card');
            productCard.innerHTML = `
                <img src="${item.photo}" alt="${item.name}">
                <h3>${item.name}</h3>
                <p>Quantity: ${item.quantity}</p>
                <p>Price: $${item.price.toFixed(2)}</p>
                <button onclick="deleteItem(${item.id})">Delete</button>
            `;
            productContainer.appendChild(productCard);
            const uploadButton = document.querySelector('#uploadButton');
            uploadButton.style.display = 'block';
        });
    } else if (currentUser.role === 'customer') {
        
        sellers.forEach(seller => {
            seller.itemsForSale.forEach(item => {
                const productCard = document.createElement('div');
                productCard.classList.add('product-card');
                productCard.innerHTML = `
                    <img src="${item.photo}" alt="${item.name}">
                    <h3>${item.name}</h3>
                    <p>Quantity: ${item.quantity}</p>
                    <p>Price: $${item.price.toFixed(2)}</p>
                    <button onclick="openPurchase(${item.id})">Purchase</button>
                `;
                productContainer.appendChild(productCard);
            });
        });
    }
    else if (currentUser.role === 'admin') {
        sellers.forEach(seller => {
            seller.itemsForSale.forEach(item => {
                const productCard = document.createElement('div');
                productCard.classList.add('product-card');
                productCard.innerHTML = `
                <img src="${item.photo}" alt="${item.name}">
                <h3>${item.name}</h3>
                <p>Quantity: ${item.quantity}</p>
                <p>Price: $${item.price.toFixed(2)}</p>
                <button onclick="deleteItem(${item.id})">Delete</button>
                `;
                productContainer.appendChild(productCard);
            });
        });
    }
}
function openUploadModal() {
   
    const uploadModal = document.querySelector('#uploadModal');
    uploadModal.style.display = 'block';
}
function uploadItem() {
    const itemName = document.querySelector('#itemName').value;
    const itemPrice = parseFloat(document.querySelector('#itemPrice').value);
    const itemQuantity = parseInt(document.querySelector('#itemQuantity').value, 10);
    const itemPhoto = document.querySelector('#itemPhoto').files[0];

    if (!itemName || isNaN(itemPrice) || isNaN(itemQuantity) || itemPrice <= 0 || itemQuantity <= 0 || !itemPhoto) {
        alert('Please fill in all fields and upload a photo.');
        return;
    }

    const seller = sellers[0];
    const newItemId = generateItemId(seller.itemsForSale.length +1);
    const newItem = {
        id: newItemId,
        name: itemName,
        price: itemPrice,
        quantity: itemQuantity,
        photo: URL.createObjectURL(itemPhoto) 
    };

    seller.itemsForSale.push(newItem);

    alert('Item uploaded successfully.');

    clearUploadForm();
    closeUploadModal()
    displayProducts();
}

function clearUploadForm() {
    document.querySelector('#itemName').value = '';
    document.querySelector('#itemPrice').value = '';
    document.querySelector('#itemQuantity').value = '';
    document.querySelector('#itemPhoto').value = '';
}

function closeUploadModal() {
  
    const uploadModal = document.querySelector('#uploadModal');
    uploadModal.style.display = 'none';
}
displayProducts();
 
function openPurchase(itemId) {
    currentPurchaseItemId = itemId;
    
    const purchaseModal = document.querySelector('#purchaseModal');
    purchaseModal.style.display = 'block';
}

function confirmPurchase() {
    if (!currentPurchaseItemId) {
        console.error("Error: No item selected for purchase.");
        return;
    }

   
    const quantity = parseInt(document.querySelector('#quantity').value);
    const address = document.querySelector('#address').value;

    if (quantity <= 0) {
        alert('Invalid quantity!');
        return;
    }

    const seller = sellers.find(seller => seller.itemsForSale.some(item => item.id === currentPurchaseItemId));

    if (!seller) {
        console.error("Error: Seller not found.");
        return;
    }

   
    const itemToPurchase = seller.itemsForSale.find(item => item.id === currentPurchaseItemId);

    if (!itemToPurchase) {
        console.error("Error: Item not found.");
        return;
    }

    if (quantity <= 0 || quantity > itemToPurchase.quantity) {
        alert('Invalid input. Please enter valid values.');
        return;
    }
    if (currentUser.moneyBalance < itemToPurchase.price * quantity ) {
        alert('Insufficient funds.');
        return;
    }
    
    const transactionId = generateTransactionId();
    const purchase = {
        transactionId: transactionId,
        itemName: itemToPurchase.name,
        quantity: quantity,
        photo: itemToPurchase.photo ,
        totalPrice: itemToPurchase.price * quantity,
        buyerAddress: address
    };

    seller.saleHistory.push(purchase);
    console.log(sellers);
   
    itemToPurchase.quantity -= quantity;
    const customerIndex = customers.findIndex(customer => customer.username === currentUser.username);
    currentUser.moneyBalance -= itemToPurchase.price * quantity;
    
    customers[customerIndex].purchaseHistory.push(purchase);

    
    closePurchaseModal();
    displayProducts();
    generatePurchaseHistoryTable()
}

function closePurchaseModal() {
    const purchaseModal = document.querySelector('#purchaseModal');
    purchaseModal.style.display = 'none';
}


function generateTransactionId() {
    return Math.floor(Math.random() * 1000000); 
}

function purchaseItem(itemId, quantity, address) {
    const item = sellers.flatMap(seller => seller.itemsForSale).find(item => item.id === itemId);
    if (item) {
        if (item.quantity >= quantity) {
            const totalPrice = item.price * quantity;
            const transactionId = generateTransactionId();
            
            
            const seller = sellers.find(seller => seller.username === item.seller);
            seller.saleHistory.push({
                transactionId: transactionId,
                itemName: item.name,
                quantity: quantity,
                totalPrice: totalPrice,
                address: address
            });
            
            
            currentUser.purchaseHistory.push({
                transactionId: transactionId,
                itemName: item.name,
                quantity: quantity,
                totalPrice: totalPrice,
                address: address
            });

            
            item.quantity -= quantity;

           
            closePurchaseModal();

      
            displayProducts();
            console.log('Purchase successful!');
        } else {
            console.log('Not enough quantity available.');
        }
    } else {
        console.log('Item not found.');
    }
}

function generateItemId(count) {
   
    return count;
}
function generatePurchaseHistoryTable() {
   
    const purchaseHistoryContainer = document.querySelector('#purchase-history');

   
    purchaseHistoryContainer.innerHTML = '';
    const table = document.createElement('table');
    table.classList.add('purchase-history-table');

   
    const headerRow = document.createElement('tr');

   
    const headers = ['Transaction ID', 'Item Name', 'Quantity', 'Total Price', 'Buyer Address'];
    headers.forEach(headerText => {
        const headerCell = document.createElement('th');
        headerCell.textContent = headerText;
        headerRow.appendChild(headerCell);
    });
    table.appendChild(headerRow);


    currentUser.purchaseHistory.forEach(purchase => {
        const row = document.createElement('tr');

       
        const cells = [
            purchase.transactionId,
            purchase.itemName,
            purchase.quantity,
            `$${purchase.totalPrice.toFixed(2)}`,
            purchase.buyerAddress
        ];

        cells.forEach(cellText => {
            const cell = document.createElement('td');
            cell.textContent = cellText;
            row.appendChild(cell);
        });

        table.appendChild(row);
    });

    purchaseHistoryContainer.appendChild(table);
}

generatePurchaseHistoryTable();

